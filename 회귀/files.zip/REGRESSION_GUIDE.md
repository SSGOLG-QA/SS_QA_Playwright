# 회귀 스위트 운영 가이드 (td17 경기관제 리뉴얼)

## Tier 구조 요약

| Tier | 스펙 파일 | 트리거 | 소요 | 범위 |
|------|-----------|--------|------|------|
| **T1 Smoke** | `Admin/regression-smoke.spec.ts` | 배포 직후 / 핫픽스·패치 후 | ~5분 | Critical path 9화면 |
| **T2 Core** | `Admin/ia-order-full.spec.ts` (기존) | 배포 전 수동 | ~25분 | 전 화면 UI 요소 전수 |
| **T3 Full** | `Admin/regression-full.spec.ts` | 매주 월요일 정기 | ~60분 | Smoke + Core + Lang + E2E |

---

## 실행 명령어

### Tier 1 — Smoke (배포 직후)
```powershell
npx playwright test --project=admin-chromium Admin/regression-smoke.spec.ts --no-deps
```

### Tier 2 — Core (배포 전)
```powershell
npx playwright test --project=admin-chromium Admin/ia-order-full.spec.ts --headed --workers=1 --no-deps
```

### Tier 3 — Full (주간 스케줄)
```powershell
# 전체
npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps --workers=1

# Phase 지정
npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps -g "Phase 1"
npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps -g "Phase 2"
npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps -g "Phase 3"
npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps -g "Phase 4"

# 스케줄 스크립트 직접 실행
.\regression-schedule.ps1
.\regression-schedule.ps1 -Phase "Phase 3"
```

---

## 파일 복사 위치

| 파일 | 복사 위치 |
|------|-----------|
| `regression-smoke.spec.ts` | `D:\Playwright\Admin\` |
| `regression-full.spec.ts` | `D:\Playwright\Admin\` |
| `regression-schedule.ps1` | `D:\Playwright\` |

---

## Windows 작업 스케줄러 등록 (Tier 3 주간 자동화)

```
작업 스케줄러 → 기본 작업 만들기
  이름   : Playwright Full Regression
  트리거 : 매주 월요일 09:00
  동작   : PowerShell -NonInteractive -File D:\Playwright\regression-schedule.ps1
```

---

## 적용 전 확인 사항

### 1. import 경로 확인 (필수)
`regression-smoke.spec.ts`와 `regression-full.spec.ts` 상단의 import 경로가
실제 `lib/helpers.ts`, `lib/reporter.ts`, `lib/suites.ts` 위치와 일치해야 합니다.

```typescript
// 현재 기본값 (실제 경로로 수정)
import { openAdmin, gotoMenu } from '../lib/helpers';
import { initReport, check, writeReport } from '../lib/reporter';
import { runHome, runRoundMgmtAll, ... } from '../lib/suites';
```

### 2. run*() 함수명 확인
`regression-full.spec.ts`의 import 목록이 `lib/suites.ts`의 실제 export 함수명과
일치하는지 확인하세요.

```powershell
# lib/suites.ts 에서 export 함수 목록 확인
Select-String -Path D:\Playwright\lib\suites.ts -Pattern "^export async function run"
```

### 3. Smoke 셀렉터 확인
`regression-smoke.spec.ts`의 각 테스트 check 셀렉터가 실제 DOM과 일치하는지
1회 headed 실행으로 확인:

```powershell
npx playwright test --project=admin-chromium Admin/regression-smoke.spec.ts --no-deps --headed
```

### 4. Phase 4 E2E 활성화 (선택)
`regression-full.spec.ts`의 Phase 4 테스트는 현재 `TODO` 상태입니다.
`Playwright_New` POM 경로 확인 후 import 연결하여 활성화하세요.

---

## 결과 판정 기준

| 결과 | 조치 |
|------|------|
| T1 Smoke FAIL | 즉시 배포 블로커 → 개발팀 핫픽스 요청 |
| T2 Core FAIL | 배포 보류 → 결함 등록 후 재검증 |
| T3 Full FAIL (Phase 1·2) | 다음 배포 전 T2 Core 재실행 |
| T3 Full FAIL (Phase 3·4만) | 다국어·E2E 전용 결함 등록, 배포 블로커 아님 |

---

## 리포트 위치

```
D:\Playwright\reports\
├── regression-smoke_report_YYYYMMDD_HHmmss.xlsx   ← T1 결과
├── ia-order-full_report_YYYYMMDD_HHmmss.xlsx       ← T2 결과 (기존)
├── regression-full_report_YYYYMMDD_HHmmss.xlsx     ← T3 결과
└── regression-logs\
    └── regression_YYYYMMDD_HHmmss.log              ← T3 실행 로그
```
