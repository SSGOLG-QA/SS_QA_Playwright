/**
 * Admin/regression-full.spec.ts
 *
 * Tier 3 — Full 회귀
 *
 * 목적  : 매주 1회 전체 회귀를 수행하여 UI 드리프트·다국어 깨짐·
 *         E2E 플로우 이상을 조기 감지한다.
 *
 * 구성  :
 *   Phase 1 — Smoke    (regression-smoke의 9개 Critical path 재실행)
 *   Phase 2 — Core     (ia-order-full의 전 화면 UI 요소 검증, 외부 호출)
 *   Phase 3 — Lang     (한국어·영어 2개 언어 × 전 메뉴 다국어 샘플)
 *   Phase 4 — E2E      (Playwright_New 핵심 플로우 4종, 외부 호출)
 *
 * 소요  : 약 50~70분 (workers=1, headless)
 * 트리거: 매주 월요일 오전 정기 스케줄 / 릴리즈 전 최종 검증
 *
 * 실행  :
 *   # 전체 Full 회귀
 *   npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps --workers=1
 *
 *   # Phase 지정 실행
 *   npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps -g "Phase 1"
 *   npx playwright test --project=admin-chromium Admin/regression-full.spec.ts --no-deps -g "Phase 3"
 *
 * 비파괴 원칙 — 저장·삭제·적용 등 데이터 변경 동작 클릭 금지.
 */

import { test } from '@playwright/test';
import { execSync } from 'child_process';
import { openAdmin, gotoMenu } from '../lib/helpers';        // [확인 필요: 실제 import 경로]
import { initReport, check, writeReport } from '../lib/reporter'; // [확인 필요: 실제 import 경로]

// 대메뉴별 run*() 함수 — lib/suites.ts 에서 import
// [확인 필요: 실제 함수명은 lib/suites.ts 기준으로 수정]
import {
  runHome,
  runRoundMgmtAll,
  runIconMgmt,
  runLiveChatNotice,
  runCartTrace,
  runTabletFeature,
  runTabletMessageEvent,
  runTimeProgress,
  runCaddie,
  runBetoStats,
  runBetoRecord,
  runHolemap,
  runCourseOps,
  runCustomerEval,
  runAccount,
} from '../lib/suites';

const SUITE  = 'regression-full';
const REPORT = initReport(SUITE);

// ── Phase 1 — Smoke (Critical path 빠른 재검증) ───────────
test.describe('Phase 1 — Smoke (Critical path)', () => {

  test('홈 GNB 진입 확인', async ({ page }) => {
    await openAdmin(page);
    check(REPORT, '홈', 'GNB 영역 노출',
      await page.locator('.depth-1-title').first().isVisible());
  });

  test('전체 라운드 진입 확인', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '라운드 관리>전체 라운드');
    check(REPORT, '라운드관리>전체라운드', '테이블 노출',
      await page.locator('table').first().isVisible());
  });

  test('아이콘 관리 진입 확인', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '관제 관리>아이콘 관리');
    check(REPORT, '관제관리>아이콘관리', '화면 진입',
      !page.url().includes('/login'));
  });

  test('진행시간 표준설정 진입 확인', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '경기 진행 관리>진행시간>표준설정');
    check(REPORT, '경기진행관리>진행시간표준설정', '화면 진입',
      !page.url().includes('/login'));
  });

  test('계정 리스트 진입 확인', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '계정 관리>계정 리스트');
    check(REPORT, '계정관리>계정리스트', '테이블 노출',
      await page.locator('table').first().isVisible());
  });

});

// ── Phase 2 — Core (전 화면 UI 요소 전수 검증) ───────────
// ia-order-full.spec.ts 와 동일한 run*() 호출 — 코드 중복 없이 재활용
test.describe('Phase 2 — Core (전 화면 UI 요소)', () => {

  test('홈', async ({ page }) => {
    await openAdmin(page);
    await runHome(page, REPORT);
  });

  test('라운드관리 전체', async ({ page }) => {
    await openAdmin(page);
    await runRoundMgmtAll(page, REPORT);
  });

  test('관제관리 — 아이콘 관리', async ({ page }) => {
    await openAdmin(page);
    await runIconMgmt(page, REPORT);
  });

  test('관제관리 — 라이브채팅 공지 조회', async ({ page }) => {
    await openAdmin(page);
    await runLiveChatNotice(page, REPORT);
  });

  test('관제관리 — 카트 이동경로 확인', async ({ page }) => {
    await openAdmin(page);
    await runCartTrace(page, REPORT);
  });

  test('태블릿 운영 관리 — 태블릿 기능 설정', async ({ page }) => {
    await openAdmin(page);
    await runTabletFeature(page, REPORT);
  });

  test('태블릿 운영 관리 — 메시지 관리 / 홀 이벤트 관리', async ({ page }) => {
    await openAdmin(page);
    await runTabletMessageEvent(page, REPORT);
  });

  test('경기 진행 관리 4종', async ({ page }) => {
    await openAdmin(page);
    await runTimeProgress(page, REPORT);
  });

  test('캐디 관리 3종', async ({ page }) => {
    await openAdmin(page);
    await runCaddie(page, REPORT);
  });

  test('배토 관리 — 배토 통계', async ({ page }) => {
    await openAdmin(page);
    await runBetoStats(page, REPORT);
  });

  test('배토 관리 — 배토 기록 조회', async ({ page }) => {
    await openAdmin(page);
    await runBetoRecord(page, REPORT);
  });

  test('홀맵 관리 4종', async ({ page }) => {
    await openAdmin(page);
    await runHolemap(page, REPORT);
  });

  test('코스 운영 관리 6종', async ({ page }) => {
    await openAdmin(page);
    await runCourseOps(page, REPORT);
  });

  test('고객 평가 관리 4종', async ({ page }) => {
    await openAdmin(page);
    await runCustomerEval(page, REPORT);
  });

  test('계정 관리 2종', async ({ page }) => {
    await openAdmin(page);
    await runAccount(page, REPORT);
  });

});

// ── Phase 3 — Lang (다국어 샘플 검증, 한국어·영어) ────────
// 전 언어 × 전 메뉴 실행 시 lang-check-all.spec.ts 사용
// 여기서는 한국어·영어 2개만 샘플 검증하여 회귀 비용 절감
test.describe('Phase 3 — Lang (다국어 샘플)', () => {

  const SAMPLE_LANGS = ['ko', 'en'] as const;  // [확인 필요: 실제 언어코드 확인]

  for (const lang of SAMPLE_LANGS) {
    test(`언어 전환 및 메뉴 노출 확인 — ${lang}`, async ({ page }) => {
      await openAdmin(page);
      // [확인 필요: 실제 언어 전환 방식 — 드롭다운 selector 수정]
      const langSelector = page.locator('.lang-select, select[name="lang"], .language-dropdown');
      const hasLangSwitch = await langSelector.isVisible().catch(() => false);

      if (!hasLangSwitch) {
        check(REPORT, `Lang-${lang}`, '언어 전환 UI 노출', false,
          '[확인 필요: 언어 전환 selector 미확인]');
        return;
      }

      await langSelector.selectOption(lang).catch(async () => {
        // 드롭다운 방식이 아닌 경우 (버튼 등) 클릭 시도
        await page.locator(`.lang-${lang}, [data-lang="${lang}"]`).click().catch(() => {});
      });

      await page.waitForLoadState('networkidle');

      // GNB 메뉴가 여전히 노출되는지 확인
      check(REPORT, `Lang-${lang}`, '언어 전환 후 GNB 노출',
        await page.locator('.depth-1-title').first().isVisible());

      // 홈 타이틀 텍스트가 언어에 맞게 변경되었는지 — 깨짐 여부 판단
      const titleText = await page.locator('h1, h2').first().textContent().catch(() => '');
      const hasMojibake = /[□■※?]{3,}/.test(titleText ?? '');
      check(REPORT, `Lang-${lang}`, '타이틀 텍스트 깨짐 없음', !hasMojibake);
    });
  }

});

// ── Phase 4 — E2E (핵심 플로우, Playwright_New 스펙 호출) ──
// workers=1 유지 — E2E 스펙은 SPA 상태 공유 위험 있음
test.describe('Phase 4 — E2E (핵심 플로우)', () => {

  test('라운드관리 E2E 플로우', async ({ page }) => {
    // Playwright_New/round-mgmt.e2e.spec.ts 의 핵심 플로우 직접 호출
    // [확인 필요: Playwright_New POM import 경로]
    // import { RoundMgmtPage } from '../Playwright_New/pages/RoundMgmtPage';
    // const roundPage = new RoundMgmtPage(page);
    // await roundPage.goto();
    // await roundPage.verifyTableLoaded();
    check(REPORT, 'E2E>라운드관리', '구현 대기', false,
      '[TODO: Playwright_New POM import 연결 후 활성화]');
  });

  test('아이콘 관리 E2E 플로우', async ({ page }) => {
    check(REPORT, 'E2E>아이콘관리', '구현 대기', false,
      '[TODO: Playwright_New POM import 연결 후 활성화]');
  });

  test('진행시간 E2E 플로우', async ({ page }) => {
    check(REPORT, 'E2E>진행시간', '구현 대기', false,
      '[TODO: Playwright_New POM import 연결 후 활성화]');
  });

  test('계정 관리 E2E 플로우', async ({ page }) => {
    check(REPORT, 'E2E>계정관리', '구현 대기', false,
      '[TODO: Playwright_New POM import 연결 후 활성화]');
  });

});

// ── 최종 리포트 저장 ────────────────────────────────────────
test.afterAll(async () => {
  await writeReport(REPORT, SUITE);
  console.log(`\n[${SUITE}] 전체 완료 — reports/${SUITE}_report_*.xlsx`);
});
