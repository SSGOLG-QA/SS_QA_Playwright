# regression-schedule.ps1
#
# 목적  : Tier 3 Full 회귀를 주간 스케줄로 자동 실행하고
#         결과를 콘솔에 출력한다.
#
# 설정  : Windows 작업 스케줄러에 아래와 같이 등록
#   - 트리거 : 매주 월요일 09:00
#   - 동작   : PowerShell -File D:\Playwright\regression-schedule.ps1
#
# 수동 실행:
#   cd D:\Playwright
#   .\regression-schedule.ps1
#
# Phase 지정 실행 (일부만):
#   .\regression-schedule.ps1 -Phase "Phase 1"
#   .\regression-schedule.ps1 -Phase "Phase 3"

param(
  [string]$Phase = ""           # 빈 문자열 = 전체 실행
)

$ROOT     = "D:\Playwright"
$LOGDIR   = "$ROOT\reports\regression-logs"
$LOGFILE  = "$LOGDIR\regression_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$SPEC     = "Admin/regression-full.spec.ts"

# ── 디렉토리 보장 ─────────────────────────────────────────
if (-not (Test-Path $LOGDIR)) { New-Item -ItemType Directory -Path $LOGDIR | Out-Null }

# ── 실행 시작 ─────────────────────────────────────────────
$startTime = Get-Date
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Tier 3 — Full 회귀 스위트 시작" -ForegroundColor Cyan
Write-Host " 시작: $startTime" -ForegroundColor Cyan
if ($Phase) { Write-Host " Phase 필터: $Phase" -ForegroundColor Yellow }
Write-Host "========================================`n" -ForegroundColor Cyan

Set-Location $ROOT

# ── 세션 유효성 사전 확인 ────────────────────────────────
$authFile = "$ROOT\auth\admin.json"
if (-not (Test-Path $authFile)) {
  Write-Host "[경고] auth/admin.json 없음 — 수동 로그인 필요" -ForegroundColor Red
  Write-Host "  실행: npx playwright test --project=setup --headed" -ForegroundColor Yellow
  exit 1
}

$authAge = (Get-Date) - (Get-Item $authFile).LastWriteTime
if ($authAge.TotalHours -gt 12) {
  Write-Host "[경고] 세션 파일이 $([math]::Round($authAge.TotalHours, 1))시간 경과 — 만료 가능성 있음" -ForegroundColor Yellow
  Write-Host "  세션 만료 시 자동 재로그인됩니다 (auth.fixture.ts 사용 시)" -ForegroundColor Gray
}

# ── Playwright 실행 ──────────────────────────────────────
$grepArg = if ($Phase) { "--grep `"$Phase`"" } else { "" }

$cmd = "npx playwright test --project=admin-chromium $SPEC --no-deps --workers=1 $grepArg"
Write-Host "실행 명령: $cmd`n" -ForegroundColor Gray

try {
  Invoke-Expression $cmd 2>&1 | Tee-Object -FilePath $LOGFILE
  $exitCode = $LASTEXITCODE
} catch {
  Write-Host "[오류] 실행 중 예외 발생: $_" -ForegroundColor Red
  $exitCode = 1
}

# ── 결과 요약 ────────────────────────────────────────────
$endTime  = Get-Date
$elapsed  = $endTime - $startTime
$elapsedStr = "{0:D2}분 {1:D2}초" -f [int]$elapsed.TotalMinutes, $elapsed.Seconds

Write-Host "`n========================================"
if ($exitCode -eq 0) {
  Write-Host " ✅ Full 회귀 완료 — PASS" -ForegroundColor Green
} else {
  Write-Host " ❌ Full 회귀 완료 — FAIL (종료코드: $exitCode)" -ForegroundColor Red
}
Write-Host " 소요: $elapsedStr"
Write-Host " 로그: $LOGFILE"
Write-Host " 리포트: $ROOT\reports\regression-full_report_*.xlsx"
Write-Host "========================================`n"

# ── 리포트 파일 최신 1개 콘솔 경로 출력 ─────────────────
$latestReport = Get-ChildItem "$ROOT\reports\regression-full_report_*.xlsx" |
  Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latestReport) {
  Write-Host "최신 리포트: $($latestReport.FullName)" -ForegroundColor Cyan
}

exit $exitCode
