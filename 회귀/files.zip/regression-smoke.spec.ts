/**
 * Admin/regression-smoke.spec.ts
 *
 * Tier 1 — Smoke 회귀
 *
 * 목적  : 배포 직후 Critical path 화면 9개의 진입 가능 여부와
 *         핵심 UI 요소 노출을 빠르게 검증한다.
 *
 * 기준  : 각 화면 진입 + 대표 요소 1~3개만 check → 빠른 판정
 * 소요  : 약 5분 (workers=1, headless)
 * 트리거: 배포 직후 즉시 실행 / 핫픽스·패치 후
 *
 * 실행  :
 *   npx playwright test --project=admin-chromium Admin/regression-smoke.spec.ts --no-deps
 *   npx playwright test --project=admin-chromium Admin/regression-smoke.spec.ts --no-deps --headed
 *
 * 비파괴 원칙 — 저장·삭제·적용 등 데이터 변경 동작 클릭 금지.
 */

import { test, expect } from '@playwright/test';
import { openAdmin, gotoMenu } from '../lib/helpers';   // [확인 필요: 실제 import 경로]
import { initReport, check, writeReport } from '../lib/reporter'; // [확인 필요: 실제 import 경로]

const SUITE  = 'regression-smoke';
const REPORT = initReport(SUITE);

// ── Smoke 판정 기준 ────────────────────────────────────────
// 각 화면: 진입 성공(URL 이탈 없음) + 대표 selector 1개 이상 노출
// FAIL 시 해당 화면 Critical 이슈 → 배포 블로커로 즉시 보고

test.describe('Tier 1 — Smoke 회귀', () => {

  test.beforeAll(async ({ browser }) => {
    // 세션 확인용 — 로그인 페이지로 빠지면 setup 재실행 필요
  });

  // ── 1. 홈 ──────────────────────────────────────────────
  test('홈 — 진입 및 GNB 노출', async ({ page }) => {
    await openAdmin(page);
    check(REPORT, '홈', 'GNB 메뉴 영역 노출',
      await page.locator('.depth-1-title').first().isVisible());
    check(REPORT, '홈', '홈 화면 타이틀 노출',
      await page.locator('h1, h2').first().isVisible());
  });

  // ── 2. 라운드관리 > 전체 라운드 ────────────────────────
  test('라운드관리 > 전체 라운드 — 진입 및 테이블 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '라운드 관리>전체 라운드');
    check(REPORT, '라운드관리>전체라운드', '테이블 헤더 노출',
      await page.locator('table thead').isVisible());
    check(REPORT, '라운드관리>전체라운드', '조회 버튼 노출',
      await page.locator('button', { hasText: /조회|검색/ }).first().isVisible());
  });

  // ── 3. 관제관리 > 아이콘 관리 ──────────────────────────
  test('관제관리 > 아이콘 관리 — 진입 및 카드 영역 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '관제 관리>아이콘 관리');
    check(REPORT, '관제관리>아이콘관리', '아이콘 카드 목록 노출',
      await page.locator('.icon-card, .card-item, .icon-list').first().isVisible().catch(() => false));
  });

  // ── 4. 태블릿 운영 관리 > 태블릿 기능 설정 ────────────
  test('태블릿 운영 관리 > 태블릿 기능 설정 — 진입 및 토글 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '태블릿 운영 관리>태블릿 기능 설정');
    check(REPORT, '태블릿운영관리>태블릿기능설정', '설정 섹션 노출',
      await page.locator('section, .setting-group').first().isVisible());
  });

  // ── 5. 경기 진행 관리 > 진행시간 표준설정 ──────────────
  test('경기 진행 관리 > 진행시간 표준설정 — 진입 및 설정 폼 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '경기 진행 관리>진행시간>표준설정');
    check(REPORT, '경기진행관리>진행시간표준설정', '설정 폼 노출',
      await page.locator('table, .form-group, .setting-row').first().isVisible());
  });

  // ── 6. 캐디 관리 > 캐디 리스트 ────────────────────────
  test('캐디 관리 > 캐디 리스트 — 진입 및 목록 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '캐디 관리>캐디 리스트');
    check(REPORT, '캐디관리>캐디리스트', '캐디 목록 테이블 노출',
      await page.locator('table').first().isVisible());
  });

  // ── 7. 홀맵 관리 > 홀맵 구역 설정 ─────────────────────
  test('홀맵 관리 > 홀맵 구역 설정 — 진입 및 지도 영역 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '홀맵 관리>홀맵 구역 설정');
    check(REPORT, '홀맵관리>홀맵구역설정', '코스 선택 또는 지도 영역 노출',
      await page.locator('.map-wrap, .course-select, canvas').first().isVisible().catch(() => false));
  });

  // ── 8. 코스 운영 관리 > 핀 포지션 관리 ────────────────
  test('코스 운영 관리 > 핀 포지션 관리 — 진입 및 테이블 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '코스 운영 관리>핀 포지션 관리');
    check(REPORT, '코스운영관리>핀포지션관리', '핀 포지션 테이블 노출',
      await page.locator('table').first().isVisible());
  });

  // ── 9. 계정 관리 > 계정 리스트 ────────────────────────
  test('계정 관리 > 계정 리스트 — 진입 및 목록 노출', async ({ page }) => {
    await openAdmin(page);
    await gotoMenu(page, '계정 관리>계정 리스트');
    check(REPORT, '계정관리>계정리스트', '계정 목록 테이블 노출',
      await page.locator('table').first().isVisible());
  });

  // ── 리포트 저장 ─────────────────────────────────────────
  test.afterAll(async () => {
    await writeReport(REPORT, SUITE);
    console.log(`\n[${SUITE}] 완료 — reports/${SUITE}_report_*.xlsx`);
  });

});
